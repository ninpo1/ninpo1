interface INotification {
    Title: string;
    IntranetNotificationDescription: string;
    IntranetNotificationBgColor: string;
    IntranetNotificationTextColor: string;   
}

export default INotification;
