interface IDiscussionBoardProps {
    listRootFolderUrl: string;
}

export default IDiscussionBoardProps;
